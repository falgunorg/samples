@extends('layouts.guest')

@section('title', 'FALGUN | ' . $category->name . ' Collection')

@section('content')
<div class="page-sample-index">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold fs-3" href="{{ route('home') }}">FALGUN</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-3">
                    <li class="nav-item"><a class="nav-link" href="{{ route('home') }}">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('samples.index') }}">Samples</a></li>
                    <li class="nav-item"><a class="nav-link active" href="{{ route('categories.index') }}">Categories</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('home') }}#factories">Factories</a></li>
                    <li class="nav-item ms-lg-2">
                        <a href="#" class="btn btn-warning rounded-pill px-4 fw-semibold">Contact Us</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <header class="py-5 bg-light border-bottom mb-4">
        <div class="container text-center text-lg-start">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center justify-content-lg-start mb-2">
                    <li class="breadcrumb-item"><a href="{{ route('home') }}" class="text-decoration-none text-muted">Home</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('categories.index') }}" class="text-decoration-none text-muted">Categories</a></li>
                    <li class="breadcrumb-item active text-dark fw-semibold" aria-current="page">{{ $category->name }}</li>
                </ol>
            </nav>
            <h1 class="display-4 fw-bold text-dark mb-2">{{ $category->name }}</h1>
            <p class="lead text-muted mb-0">Discover our collection of premium apparel items matching the <span class="fw-bold text-dark">{{ $category->name }}</span> collection structure.</p>
        </div>
    </header>

    <section class="py-4 bg-white">
        <div class="container">
            <div class="position-relative">
                <div class="row align-items-center g-4">
                    <div class="col-lg-3">
                        <span class="filter-mini-title text-muted small fw-bold">CHOOSE YOUR DESIGN</span>
                        <h3 class="fw-bold mb-2">Filter Samples</h3>
                        <p class="text-muted small mb-0">Refine the current category items by design keywords or designated buyers.</p>
                    </div>

                    <div class="col-lg-9">
                        <form method="GET" action="{{ url()->current() }}" id="filterForm">
                            <div class="row g-3">
                                <div class="col-lg-5">
                                    <div class="modern-input-group">
                                        <input type="text" name="search" class="form-control" placeholder="Search within this category..." value="{{ request('search') }}">
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <select name="buyer" class="form-select" onchange="document.getElementById('filterForm').submit();">
                                        <option value="All Buyers">All Buyers</option>
                                        @foreach($buyers as $buyer)
                                        <option value="{{ $buyer->name }}" {{ request('buyer') == $buyer->name ? 'selected' : '' }}>{{ $buyer->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="col-lg-3 d-flex gap-2">
                                    <button type="submit" class="btn btn-dark w-100">Apply</button>
                                    @if(request('search') || (request('buyer') && request('buyer') !== 'All Buyers'))
                                    <a href="{{ url()->current() }}" class="btn btn-outline-danger" title="Clear Filters">
                                        Clear
                                    </a>
                                    @endif
                                </div>
                            </div>                          
                        </form>
                    </div>
                </div>
            </div>
            <br/>

            <div class="row g-4" id="samplesContainer">
                @include('frontend.samples.partials.grid_items')
                @if($samples->isEmpty())
                <div class="col-12 text-center py-5">
                    <p class="text-muted fs-5">No sample records are currently available matching your exact selections.</p>
                </div>
                @endif
            </div>
            <br/><br/>

            <div class="text-center mt-4">
                <button type="button" 
                        class="btn btn-outline-dark btn-lg rounded-pill px-4" 
                        id="loadMoreBtn"
                        data-next-page="{{ $samples->nextPageUrl() }}"
                        style="{{ $samples->hasMorePages() ? '' : 'display: none;' }}">
                    <span class="spinner-border spinner-border-sm me-2 d-none" id="btnSpinner" role="status"></span>
                    LOAD MORE
                </button>

                <div id="noMoreMessage" class="text-muted small text-uppercase fw-semibold {{ !$samples->hasMorePages() && $samples->total() > 0 ? '' : 'd-none' }}">
                    You've viewed all matching items within {{ $category->name }}
                </div>
            </div>

        </div>
    </section>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const loadMoreBtn = document.getElementById('loadMoreBtn');
        const samplesContainer = document.getElementById('samplesContainer');
        const btnSpinner = document.getElementById('btnSpinner');
        const noMoreMessage = document.getElementById('noMoreMessage');

        if (loadMoreBtn) {
            loadMoreBtn.addEventListener('click', function () {
                let nextPageUrl = loadMoreBtn.getAttribute('data-next-page');
                if (!nextPageUrl)
                    return;

                loadMoreBtn.disabled = true;
                btnSpinner.classList.remove('d-none');

                fetch(nextPageUrl, {
                    headers: {"X-Requested-With": "XMLHttpRequest"}
                })
                        .then(response => {
                            if (!response.ok)
                                throw new Error("HTTP Connection exception");
                            return response.text();
                        })
                        .then(htmlData => {
                            if (htmlData.trim() === '') {
                                loadMoreBtn.style.display = 'none';
                                noMoreMessage.classList.remove('d-none');
                            } else {
                                samplesContainer.insertAdjacentHTML('beforeend', htmlData);

                                let urlObj = new URL(nextPageUrl);
                                let currentPage = parseInt(urlObj.searchParams.get('page')) || 1;
                                urlObj.searchParams.set('page', currentPage + 1);
                                let deeperPageUrl = urlObj.toString();

                                loadMoreBtn.setAttribute('data-next-page', deeperPageUrl);
                                loadMoreBtn.disabled = false;
                            }
                        })
                        .catch(err => {
                            console.error("AJAX error execution encountered during next sequence pagination chunk fetch:", err);
                            loadMoreBtn.disabled = false;
                        })
                        .finally(() => {
                            btnSpinner.classList.add('d-none');
                        });
            });
        }
    });
</script>
@endsection
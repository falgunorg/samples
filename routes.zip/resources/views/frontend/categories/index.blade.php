@extends('layouts.guest')

@section('title', 'FALGUN | Premium Category Collection')

@section('content')
<div class="page-sample-index">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold fs-3" href="{{ route('home') }}">FALGUN</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-3">
                    <li class="nav-item"><a class="nav-link" href="{{ route('home') }}">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('samples.index') }}">Samples</a></li>
                    <li class="nav-item"><a class="nav-link active" href="{{ route('categories.index') }}">Categories</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('home') }}#factories">Factories</a></li>
                    <li class="nav-item ms-lg-2">
                        <a href="#" class="btn btn-warning rounded-pill px-4 fw-semibold">Contact Us</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="py-5 bg-white">
        <div class="container">
            <div class="position-relative">
                <div class="row align-items-center g-4">
                    <div class="col-lg-3">
                        <span class="filter-mini-title text-muted small fw-bold">FIND YOUR CATEGORIES</span>
                        <h3 class="fw-bold mb-2">Filter Categories</h3>
                        <p class="text-muted small mb-0">Search premium apparel collections by buyer, category, or garment type.</p>
                    </div>

                    <div class="col-lg-9">
                        <form method="GET" action="{{ route('categories.index') }}" id="filterForm">
                            <div class="row g-3">
                                <div class="col-lg-4">
                                    <div class="modern-input-group">
                                        <input type="text" name="search" class="form-control" placeholder="Search categories..." value="{{ request('search') }}">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <br/>

            <div class="row g-4" id="categories-wrapper">
                @forelse($categories as $cat)
                <div class="col-lg-3 col-md-4 col-6" data-aos="zoom-in">
                    <a href="{{route('categories.show', $cat->slug)}}">
                        <div class="position-relative rounded-4 overflow-hidden shadow-sm category-card">
                            <img src="{{ asset($cat->img) }}"
                                 class="w-100 category-img"
                                 alt="{{ $cat->name }}"
                                 style="height: 380px; background: #ffcd39; object-fit: contain;"> 
                            <div class="position-absolute bottom-0 start-0 w-100 p-3"
                                 style="background: linear-gradient(to top, rgba(0,0,0,0.85), rgba(0,0,0,0.4), transparent);">
                                <h6 class="text-white fw-bold mb-0">{{ $cat->name }}</h6>
                                <small class="text-warning">{{ $cat->samples_count }} Samples</small>
                            </div>
                        </div>

                    </a>

                </div>
                @empty
                <div class="col-12 text-center py-5">
                    <p class="text-muted">No categories found matching your search.</p>
                </div>
                @endforelse
            </div>
            <br/><br/>

            <div class="text-center mt-4">
                <button type="button" 
                        class="btn btn-outline-dark btn-lg rounded-pill px-4" 
                        id="loadMoreBtn"
                        data-next-page="{{ $categories->nextPageUrl() }}"
                        style="{{ $categories->hasMorePages() ? '' : 'display: none;' }}">
                    <span class="spinner-border spinner-border-sm me-2 d-none" id="btnSpinner" role="status"></span>
                    LOAD MORE
                </button>

                <div id="noMoreMessage" class="text-muted small text-uppercase fw-semibold {{ !$categories->hasMorePages() && $categories->total() > 0 ? '' : 'd-none' }}">
                    You've viewed all matching items
                </div>
            </div>

            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    const loadMoreBtn = document.getElementById('loadMoreBtn');

                    if (loadMoreBtn) {
                        loadMoreBtn.addEventListener('click', function () {
                            let button = this;
                            let nextPageUrl = button.getAttribute('data-next-page');
                            let spinner = document.getElementById('btnSpinner');
                            let noMoreMsg = document.getElementById('noMoreMessage');
                            let wrapper = document.getElementById('categories-wrapper');

                            if (!nextPageUrl)
                                return;

                            // UI Loading Feedback
                            spinner.classList.remove('d-none');
                            button.disabled = true;

                            // Async Fetch Connection Handshake
                            fetch(nextPageUrl, {
                                headers: {
                                    'X-Requested-With': 'XMLHttpRequest'
                                }
                            })
                                    .then(response => {
                                        if (!response.ok)
                                            throw new Error('Network error received.');
                                        return response.json();
                                    })
                                    .then(data => {
                                        // Dynamic elements processing and placement
                                        wrapper.insertAdjacentHTML('beforeend', data.html);

                                        // Component state updates
                                        if (data.hasMorePages) {
                                            button.setAttribute('data-next-page', data.nextPageUrl);
                                            button.disabled = false;
                                        } else {
                                            button.style.display = 'none';
                                            noMoreMsg.classList.remove('d-none');
                                        }
                                    })
                                    .catch(error => {
                                        console.error('Error fetching data execution:', error);
                                        button.disabled = false;
                                    })
                                    .finally(() => {
                                        spinner.classList.add('d-none');
                                    });
                        });
                    }
                });
            </script>

        </div>
    </section>
</div>
@endsection